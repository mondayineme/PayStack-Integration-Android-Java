# Paystack-Android-Tutorial
### A sample tutorial app that shows how to integrate Paystack payment in android
#### For detailed guide on how to integrate this, check my Medium article [here](https://medium.com/@ikhiloyaimokhai/integrating-paystack-payment-on-android-application-3eec3a7c0bbf)
